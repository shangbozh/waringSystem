package springmvc.entity;

import java.util.Date;

public class ReadHistory extends ReadHistoryKey {
    private Date readTime;

    public Date getReadTime() {
        return readTime;
    }

    public void setReadTime(Date readTime) {
        this.readTime = readTime;
    }
}