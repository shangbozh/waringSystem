package springmvc.entity;

import java.util.Date;

public class WaringHistory {
    private Long waringId;

    private String wTitle;

    private Date wPdate;

    private Date wDeldate;

    private Integer readTimes;

    private String wContent;

    public Long getWaringId() {
        return waringId;
    }

    public void setWaringId(Long waringId) {
        this.waringId = waringId;
    }

    public String getwTitle() {
        return wTitle;
    }

    public void setwTitle(String wTitle) {
        this.wTitle = wTitle;
    }

    public Date getwPdate() {
        return wPdate;
    }

    public void setwPdate(Date wPdate) {
        this.wPdate = wPdate;
    }

    public Date getwDeldate() {
        return wDeldate;
    }

    public void setwDeldate(Date wDeldate) {
        this.wDeldate = wDeldate;
    }

    public Integer getReadTimes() {
        return readTimes;
    }

    public void setReadTimes(Integer readTimes) {
        this.readTimes = readTimes;
    }

    public String getwContent() {
        return wContent;
    }

    public void setwContent(String wContent) {
        this.wContent = wContent;
    }
}