package springmvc.entity;

import java.util.Date;

public class WaringInfo {
    private Long waringId;

    private String wTitle;

    private Date wPdate;

    private String grade;

    private Integer publishOrganId;

    private String wContent;

    public Long getWaringId() {
        return waringId;
    }

    public void setWaringId(Long waringId) {
        this.waringId = waringId;
    }

    public String getwTitle() {
        return wTitle;
    }

    public void setwTitle(String wTitle) {
        this.wTitle = wTitle;
    }

    public Date getwPdate() {
        return wPdate;
    }

    public void setwPdate(Date wPdate) {
        this.wPdate = wPdate;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Integer getPublishOrganId() {
        return publishOrganId;
    }

    public void setPublishOrganId(Integer publishOrganId) {
        this.publishOrganId = publishOrganId;
    }

    public String getwContent() {
        return wContent;
    }

    public void setwContent(String wContent) {
        this.wContent = wContent;
    }
}