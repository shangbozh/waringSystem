package springmvc.entity;

public class Police {
    private Integer policeId;

    private String organName;

    private String password;

    private String address;

    private Long officeTel;

    public Integer getPoliceId() {
        return policeId;
    }

    public void setPoliceId(Integer policeId) {
        this.policeId = policeId;
    }

    public String getOrganName() {
        return organName;
    }

    public void setOrganName(String organName) {
        this.organName = organName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getOfficeTel() {
        return officeTel;
    }

    public void setOfficeTel(Long officeTel) {
        this.officeTel = officeTel;
    }
}