package springmvc.entity;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class PoliceBatchUpload {
    private int totalRows;

    private int totalCells;

    private String errorMsg;


    //获取excel信息
    public List<Police> getExcelInfo(MultipartFile mFile) {
        String fileName = mFile.getOriginalFilename();//获取文件名
        List<Police> policeList = null;
        try {
            if (!validateExcel(fileName)) {// 验证文件名是否合格
                return null;
            }
            boolean isExcel2003 = true;// 根据文件名判断文件是2003版本还是2007版本
            if (isExcel2007(fileName)) {
                isExcel2003 = false;
            }
            policeList = createExcel(mFile.getInputStream(), isExcel2003);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return policeList;
    }

    //验证Excel表格信息
    public List<Police> createExcel(InputStream is, boolean isExcel2003) {
        List<Police> policeList = null;
        Workbook wb = null;
        try {
            if (isExcel2003) {
                wb = new HSSFWorkbook(is);
            } else {
                wb = new XSSFWorkbook(is);
            }
            policeList = readExcelValue(wb);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return policeList;
    }

    //获取Excel表格中的信息转换成实体，并向上返回
    private List<Police> readExcelValue(Workbook wb) {
        //拿到第一个shell
        Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        this.totalRows = sheet.getPhysicalNumberOfRows();
        System.out.println("行数=======" + this.totalRows);
        //得到Excel的列数
        if (totalRows > 1 && sheet.getRow(0) != null) {
            this.totalCells = sheet.getRow(0).getPhysicalNumberOfCells();
            System.out.println("总列数==========" + this.totalCells);
        }
        List<Police> policeList = new ArrayList<>();
        //遍历行
        for (int r = 1; r < totalRows; r++) {
            Row row = sheet.getRow(r);
            if (row == null)
                continue;
            Police police = new Police();
            //遍历列
            for (int c = 0; c < this.totalCells; c++) {
                Cell cell = row.getCell(c);
                if (cell != null) {
                    if (c == 0) {
                        police.setPoliceId(Integer.parseInt(cell.getStringCellValue()));
                    } else if (c == 1) {
                        police.setPassword(cell.getStringCellValue());
                    } else if (c == 2) {
                        police.setOrganName(cell.getStringCellValue());
                    } else if (c == 3) {
                        police.setAddress(cell.getStringCellValue());
                    } else if (c == 4) {
                        police.setOfficeTel(Long.parseLong(cell.getStringCellValue()));
                    }
                }
            }
            policeList.add(police);
        }
        return policeList;
    }


    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getTotalCells() {
        return totalCells;
    }

    public void setTotalCells(int totalCells) {
        this.totalCells = totalCells;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    //验证文件名
    public boolean validateExcel(String filePath) {
        if (filePath == null || !(isExcel2003(filePath) || isExcel2007(filePath))) {
            errorMsg = "文件名不是excel格式";
            return false;
        }
        return true;
    }

    // @描述：是否是2003的excel，返回true是2003
    public static boolean isExcel2003(String filePath) {
        return filePath.matches("^.+\\.(?i)(xls)$");
    }

    //@描述：是否是2007的excel，返回true是2007
    public static boolean isExcel2007(String filePath) {
        return filePath.matches("^.+\\.(?i)(xlsx)$");
    }
}
