package springmvc.entity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class ProvinceAndCity {
    private List<String> beijing;
    private List<String> shanghai;
    private List<String> tianjin;
    private List<String> chongqing;
    private List<String> hebei;
    private List<String> henan;
    private List<String> yunnan;
    private List<String> liaoning;
    private List<String> heilongjiang;
    private List<String> hunan;
    private List<String> anhui;
    private List<String> shandong;
    private List<String> xinjiang;
    private List<String> jiangsu;
    private List<String> zhejiang;
    private List<String> jiangxi;
    private List<String> hubei;
    private List<String> guangxi;
    private List<String> gansu;
    private List<String> shan1xi;
    private List<String> neimenggu;
    private List<String> shan3xi;
    private List<String> jilin;
    private List<String> fujian;
    private List<String> guizhou;
    private List<String> guangdong;
    private List<String> qinghai;
    private List<String> xizang;
    private List<String> sichuan;
    private List<String> ningxia;
    private List<String> hainan;
    private List<String> taiwan;
    private List<String> xianggang;
    private List<String> aomen;

}
