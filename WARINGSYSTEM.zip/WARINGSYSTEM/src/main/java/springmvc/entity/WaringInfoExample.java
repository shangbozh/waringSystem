package springmvc.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class WaringInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public WaringInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andWaringIdIsNull() {
            addCriterion("Waring_ID is null");
            return (Criteria) this;
        }

        public Criteria andWaringIdIsNotNull() {
            addCriterion("Waring_ID is not null");
            return (Criteria) this;
        }

        public Criteria andWaringIdEqualTo(Long value) {
            addCriterion("Waring_ID =", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdNotEqualTo(Long value) {
            addCriterion("Waring_ID <>", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdGreaterThan(Long value) {
            addCriterion("Waring_ID >", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdGreaterThanOrEqualTo(Long value) {
            addCriterion("Waring_ID >=", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdLessThan(Long value) {
            addCriterion("Waring_ID <", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdLessThanOrEqualTo(Long value) {
            addCriterion("Waring_ID <=", value, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdIn(List<Long> values) {
            addCriterion("Waring_ID in", values, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdNotIn(List<Long> values) {
            addCriterion("Waring_ID not in", values, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdBetween(Long value1, Long value2) {
            addCriterion("Waring_ID between", value1, value2, "waringId");
            return (Criteria) this;
        }

        public Criteria andWaringIdNotBetween(Long value1, Long value2) {
            addCriterion("Waring_ID not between", value1, value2, "waringId");
            return (Criteria) this;
        }

        public Criteria andWTitleIsNull() {
            addCriterion("W_title is null");
            return (Criteria) this;
        }

        public Criteria andWTitleIsNotNull() {
            addCriterion("W_title is not null");
            return (Criteria) this;
        }

        public Criteria andWTitleEqualTo(String value) {
            addCriterion("W_title =", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleNotEqualTo(String value) {
            addCriterion("W_title <>", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleGreaterThan(String value) {
            addCriterion("W_title >", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleGreaterThanOrEqualTo(String value) {
            addCriterion("W_title >=", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleLessThan(String value) {
            addCriterion("W_title <", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleLessThanOrEqualTo(String value) {
            addCriterion("W_title <=", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleLike(String value) {
            addCriterion("W_title like", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleNotLike(String value) {
            addCriterion("W_title not like", value, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleIn(List<String> values) {
            addCriterion("W_title in", values, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleNotIn(List<String> values) {
            addCriterion("W_title not in", values, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleBetween(String value1, String value2) {
            addCriterion("W_title between", value1, value2, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWTitleNotBetween(String value1, String value2) {
            addCriterion("W_title not between", value1, value2, "wTitle");
            return (Criteria) this;
        }

        public Criteria andWPdateIsNull() {
            addCriterion("W_pdate is null");
            return (Criteria) this;
        }

        public Criteria andWPdateIsNotNull() {
            addCriterion("W_pdate is not null");
            return (Criteria) this;
        }

        public Criteria andWPdateEqualTo(Date value) {
            addCriterionForJDBCDate("W_pdate =", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateNotEqualTo(Date value) {
            addCriterionForJDBCDate("W_pdate <>", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateGreaterThan(Date value) {
            addCriterionForJDBCDate("W_pdate >", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("W_pdate >=", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateLessThan(Date value) {
            addCriterionForJDBCDate("W_pdate <", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("W_pdate <=", value, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateIn(List<Date> values) {
            addCriterionForJDBCDate("W_pdate in", values, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateNotIn(List<Date> values) {
            addCriterionForJDBCDate("W_pdate not in", values, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("W_pdate between", value1, value2, "wPdate");
            return (Criteria) this;
        }

        public Criteria andWPdateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("W_pdate not between", value1, value2, "wPdate");
            return (Criteria) this;
        }

        public Criteria andGradeIsNull() {
            addCriterion("grade is null");
            return (Criteria) this;
        }

        public Criteria andGradeIsNotNull() {
            addCriterion("grade is not null");
            return (Criteria) this;
        }

        public Criteria andGradeEqualTo(String value) {
            addCriterion("grade =", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeNotEqualTo(String value) {
            addCriterion("grade <>", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeGreaterThan(String value) {
            addCriterion("grade >", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeGreaterThanOrEqualTo(String value) {
            addCriterion("grade >=", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeLessThan(String value) {
            addCriterion("grade <", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeLessThanOrEqualTo(String value) {
            addCriterion("grade <=", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeLike(String value) {
            addCriterion("grade like", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeNotLike(String value) {
            addCriterion("grade not like", value, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeIn(List<String> values) {
            addCriterion("grade in", values, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeNotIn(List<String> values) {
            addCriterion("grade not in", values, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeBetween(String value1, String value2) {
            addCriterion("grade between", value1, value2, "grade");
            return (Criteria) this;
        }

        public Criteria andGradeNotBetween(String value1, String value2) {
            addCriterion("grade not between", value1, value2, "grade");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdIsNull() {
            addCriterion("publish_organ_ID is null");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdIsNotNull() {
            addCriterion("publish_organ_ID is not null");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdEqualTo(Integer value) {
            addCriterion("publish_organ_ID =", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdNotEqualTo(Integer value) {
            addCriterion("publish_organ_ID <>", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdGreaterThan(Integer value) {
            addCriterion("publish_organ_ID >", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("publish_organ_ID >=", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdLessThan(Integer value) {
            addCriterion("publish_organ_ID <", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdLessThanOrEqualTo(Integer value) {
            addCriterion("publish_organ_ID <=", value, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdIn(List<Integer> values) {
            addCriterion("publish_organ_ID in", values, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdNotIn(List<Integer> values) {
            addCriterion("publish_organ_ID not in", values, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdBetween(Integer value1, Integer value2) {
            addCriterion("publish_organ_ID between", value1, value2, "publishOrganId");
            return (Criteria) this;
        }

        public Criteria andPublishOrganIdNotBetween(Integer value1, Integer value2) {
            addCriterion("publish_organ_ID not between", value1, value2, "publishOrganId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}