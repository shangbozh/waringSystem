package springmvc.entity;

public class ReadHistoryKey {
    private Long waringId;

    private Long readUser;

    public Long getWaringId() {
        return waringId;
    }

    public void setWaringId(Long waringId) {
        this.waringId = waringId;
    }

    public Long getReadUser() {
        return readUser;
    }

    public void setReadUser(Long readUser) {
        this.readUser = readUser;
    }
}