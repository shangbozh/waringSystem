package springmvc.entity;

public class WaringInfoSource {
    private Long waringSourceId;

    private String wTitle;

    private String grade;

    private String source;

    private String wContent;

    public Long getWaringSourceId() {
        return waringSourceId;
    }

    public void setWaringSourceId(Long waringSourceId) {
        this.waringSourceId = waringSourceId;
    }

    public String getwTitle() {
        return wTitle;
    }

    public void setwTitle(String wTitle) {
        this.wTitle = wTitle;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getwContent() {
        return wContent;
    }

    public void setwContent(String wContent) {
        this.wContent = wContent;
    }
}