package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import springmvc.entity.ReadHistory;
import springmvc.entity.User;
import springmvc.service.ReadHistoryService;
import springmvc.service.UserService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;
    @Autowired
    ReadHistoryService readHistoryService;

    @RequestMapping("/user_login")
    public String user_login(@RequestParam("username") String username,
                             @RequestParam("password") String password, HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (username == "") {
            session.setAttribute("msg", "用户名不能为空");
            return "user/user_login";
        }
        if (password == "") {
            session.setAttribute("msg", "密码不能为空");
            return "user/user_login";
        }
        User user = userService.user_login(username, password);
        if (user == null) {
            session.setAttribute("msg", "帐号或密码错误！");
            return "user/user_login";
        } else {
            session.setAttribute("user", user);
            return "/index";
        }
    }

    @RequestMapping("/user_register")
    public String user_register(@RequestParam("username") String username,
                                @RequestParam("password") String password,
                                @RequestParam("repassword") String repassword, HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (username == "") {
            session.setAttribute("msg", "用户名不能为空");
            return "user/register";
        }
        if (password == "") {
            session.setAttribute("msg", "密码不能为空");
            return "user/register";
        }
        if (repassword == "") {
            session.setAttribute("msg", "确认密码不能为空");
            return "user/register";
        }
        if (!password.equals(repassword)) {
            session.setAttribute("msg", "两次密码不一致");
            return "user/register";
        }
        int i = userService.user_register(username, password);
        if (i == 0) {
            session.setAttribute("msg", "注册失败!");
            return "user/user_login";
        } else {
            User user = userService.selectUserByPk(username);
            session.setAttribute("user", user);
            return "/index";
        }
    }

    @RequestMapping("/selectUser_info")
    @ResponseBody
    public User selectUser_info(@RequestParam("phoneNum") String phoneNum) {
        User user = userService.selectUserByPk(phoneNum);
        return user;
    }

    @RequestMapping("/changeUser_info")
    @ResponseBody
    public int changeUser_info(@RequestBody User user) {
        return userService.updateUserSelective(user);
    }

    @RequestMapping("/changePSW")
    @ResponseBody
    public int changePSW(@RequestBody User user) {
        return userService.updateUserSelective(user);
    }

    @RequestMapping("/userOff")
    @ResponseBody
    public int userOff(@RequestParam("phoneNum") String phoneNum) {
        return userService.userOff(Long.parseLong(phoneNum));
    }


    @RequestMapping("/read_waring")
    @ResponseBody
    public int read_waring(@RequestBody ReadHistory readHistory) {
        readHistory.setReadTime(new Date());
        return readHistoryService.insertReadHistory(readHistory);
    }
}
