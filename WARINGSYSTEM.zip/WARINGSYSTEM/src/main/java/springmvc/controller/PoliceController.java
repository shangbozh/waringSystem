package springmvc.controller;

import org.omg.CORBA.MARSHAL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import springmvc.entity.Police;
import springmvc.entity.ReadHistory;
import springmvc.entity.WaringInfo;
import springmvc.service.PoliceService;
import springmvc.service.ReadHistoryService;
import springmvc.service.WaringInfoService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
@RequestMapping("/police")
public class PoliceController {
    @Autowired
    PoliceService policeService;
    @Autowired
    WaringInfoService waringInfoService;
    @Autowired
    ReadHistoryService readHistoryService;

    @RequestMapping("/police_login")
    public String police_login(@RequestParam("username") String username,
                               @RequestParam("password") String password, HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (username == "") {
            session.setAttribute("msg", "用户名不能为空");
            return "police/police_login";
        }
        if (password == "") {
            session.setAttribute("msg", "密码不能为空");
            return "police/police_login";
        }
        Police police = policeService.police_login(username, password);
        if (police == null) {
            session.setAttribute("msg", "帐号或密码错误！");
            return "police/police_login";
        } else {
            session.setAttribute("police", police);
            return "police/pIndex";
        }
    }


    @RequestMapping("/changePSW")
    @ResponseBody
    public int changePSW(@RequestBody Police police) {
        return policeService.changePSW(police);
    }

    @RequestMapping("/selectPolice_info")
    @ResponseBody
    public Police selectPolice_info(@RequestParam("policeId") String policeId) {
        return policeService.selectPoliceInfo(Integer.parseInt(policeId));
    }

    @RequestMapping("/changePolice_info")
    @ResponseBody
    public int changePolice_info(@RequestBody Police police) {
        return policeService.updatePoliceSelective(police);
    }

    @RequestMapping("/policeOff")
    @ResponseBody
    public int policeOff(@RequestParam("policeId") String policeId) {
        return policeService.policeOff(Integer.parseInt(policeId));
    }

    @RequestMapping("/add_waring_info")
    @ResponseBody
    public int add_waring_info(@RequestBody WaringInfo waringInfo) {
        waringInfo.setwPdate(new Date());
        return waringInfoService.add_waring_info(waringInfo);
    }

    @RequestMapping("/selectAll_waring_info")
    @ResponseBody
    public Map<String, Object> selectAll_waring_info(@RequestParam("page") int page,
                                                     @RequestParam("limit") int limit) {
        List<WaringInfo> waringInfos = waringInfoService.selectByPage(limit * (page - 1), limit);
        HashMap<String, Object> waringMap = new HashMap<>();
        waringMap.put("code", 0);
        waringMap.put("msg", "ok");
        waringMap.put("count", waringInfoService.countAllWaring());
        waringMap.put("data", waringInfos);
        return waringMap;
    }

    @RequestMapping("/deleteWaring_info")
    @ResponseBody
    public int deleteWaring_info(@RequestParam("waringId") String waringId) {
        return waringInfoService.deleteWaringInfo(Long.parseLong(waringId));
    }

    @RequestMapping("/deleteSelectedWaring_info")
    @ResponseBody
    public int deleteSelectedWaring_info(@RequestBody List<WaringInfo> waringInfos) {

        return waringInfoService.deleteSelectedWaring_info((ArrayList<WaringInfo>) waringInfos);
    }

    @RequestMapping("/selectWaring_Conditions")
    @ResponseBody
    public Map<String, Object> selectWaring_Conditions(@RequestParam("page") int page,
                                                       @RequestParam("limit") int limit,
                                                       @RequestParam("wTitle_search") String wTitle_search,
                                                       @RequestParam("publish_organ_search") String publish_organ_search,
                                                       @RequestParam("grade_search") String grade_search,
                                                       @RequestParam("pDate_search") String pDate_search) {
        if (wTitle_search.equals(""))
            wTitle_search = null;
        if (publish_organ_search.equals(""))
            publish_organ_search = null;
        if (grade_search.equals("0"))
            grade_search = null;
        if (pDate_search.equals(""))
            pDate_search = null;
        System.out.println(pDate_search);
        List<WaringInfo> waringInfos = waringInfoService.selectByConditions(limit * (page - 1), limit, wTitle_search, publish_organ_search, grade_search, pDate_search);
        HashMap<String, Object> waringInfoMap = new HashMap<>();
        waringInfoMap.put("code", 0);
        waringInfoMap.put("msg", "ok");
        waringInfoMap.put("count", waringInfoService.countWaringByConditions(wTitle_search, publish_organ_search, grade_search, pDate_search));
        waringInfoMap.put("data", waringInfos);
        return waringInfoMap;
    }

    @RequestMapping("/selectAll_read_history")
    @ResponseBody
    public Map<String, Object> selectAll_read_history(@RequestParam("page") int page,
                                                      @RequestParam("limit") int limit) {
        List<ReadHistory> readHistories = readHistoryService.selectByPage(limit * (page - 1), limit);
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", 0);
        map.put("msg", "ok");
        map.put("count", readHistoryService.countAllReadHistory());
        map.put("data", readHistories);
        return map;
    }

    @RequestMapping("/select_read_historyByCondition")
    @ResponseBody
    public Map<String, Object> select_read_historyByCondition(@RequestParam("page") int page,
                                                              @RequestParam("limit") int limit,
                                                              @RequestParam("readTitle_search") String readTitle_search,
                                                              @RequestParam("readDate_search") String readDate_search) {
        if (readDate_search.equals(""))
            readDate_search = null;
        if (readTitle_search.equals(""))
            readTitle_search = null;
        List<ReadHistory> readHistories = readHistoryService.selectByPageByConditions(limit * (page - 1), limit, readTitle_search, readDate_search);
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", 0);
        map.put("msg", "ok");
        map.put("count", readHistoryService.countReadHistoryByConditions(readTitle_search, readDate_search));
        map.put("data", readHistories);
        return map;
    }


}
