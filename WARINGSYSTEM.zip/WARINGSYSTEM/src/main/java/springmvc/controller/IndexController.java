package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import springmvc.entity.WaringInfo;
import springmvc.service.WaringInfoService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/")
public class IndexController {
    @Autowired
    WaringInfoService waringInfoService;

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/user_login")
    public String user_login() {
        return "user/user_login";
    }

    @RequestMapping("/register")
    public String register() {
        return "user/register";
    }

    @RequestMapping("/police_login")
    public String police_login() {
        return "police/police_login";
    }

    @RequestMapping("/admin_login")
    public String admin_login() {
        return "admin/admin_login";
    }

    @RequestMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate();
        return "/index";
    }

    @RequestMapping("/selectWaringByProvince")
    @ResponseBody
    public Map<String, Object> selectWaringByProvince(@RequestParam("limit") int limit,
                                                      @RequestParam("page") int page,
                                                      @RequestParam("provinceName") String provinceName) {
        List<WaringInfo> waringInfos = waringInfoService.selectByProvince(limit * (page - 1), limit, provinceName);
        HashMap<String, Object> waringMap = new HashMap<>();
        waringMap.put("code", 0);
        waringMap.put("msg", "ok");
        waringMap.put("count", waringInfoService.countByPoliceId(provinceName));
        waringMap.put("data", waringInfos);
        return waringMap;
    }

    @RequestMapping("/selectWaringByProvinceAndCity")
    @ResponseBody
    public Map<String, Object> selectWaringByProvinceAndCity(@RequestParam("provinceName") String provinceName,
                                                             @RequestParam("city") String city,
                                                             @RequestParam("time") String time,
                                                             @RequestParam("limit") int limit,
                                                             @RequestParam("page") int page) {
        if (provinceName.equals(""))
            provinceName = null;
        if (city.equals(""))
            city = null;
        if (time.equals(""))
            time = null;
        List<WaringInfo> waringInfos = waringInfoService.selectByProvinceAndConditions(limit * (page - 1), limit, provinceName, city, time);
        HashMap<String, Object> waringMap = new HashMap<>();
        waringMap.put("code", 0);
        waringMap.put("msg", "ok");
        waringMap.put("count", waringInfoService.countByPoliceIdAndConditions(provinceName, city, time));
        waringMap.put("data", waringInfos);
        return waringMap;
    }
}
