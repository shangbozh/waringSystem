package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import springmvc.entity.Admin;
import springmvc.entity.Police;
import springmvc.entity.User;
import springmvc.service.AdminService;
import springmvc.service.PoliceService;
import springmvc.service.UserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    AdminService adminService;
    @Autowired
    UserService userService;
    @Autowired
    PoliceService policeService;

    @RequestMapping("/admin_login")
    public String police_login(@RequestParam("username") String username,
                               @RequestParam("password") String password, HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (username == "") {
            session.setAttribute("msg", "用户名不能为空");
            return "admin/admin_login";
        }
        if (password == "") {
            session.setAttribute("msg", "密码不能为空");
            return "admin/admin_login";
        }
        Admin admin = adminService.admin_login(username, password);
        if (admin == null) {
            session.setAttribute("msg", "帐号或密码错误！");
            return "admin/admin_login";
        } else {
            session.setAttribute("admin", admin);
            return "admin/aIndex";
        }
    }

    @RequestMapping("/selectAll_user_info")
    @ResponseBody
    public Map<String, Object> selectAll_user_info(@RequestParam("page") int page,
                                                   @RequestParam("limit") int limit) {
        List<User> users = userService.selectByPage(limit * (page - 1), limit);
        Map<String, Object> allUserMap = new HashMap<>();
        allUserMap.put("code", 0);
        allUserMap.put("msg", "ok");
        allUserMap.put("count", userService.countAllUser());
        allUserMap.put("data", users);
        return allUserMap;
    }

    @RequestMapping("/uploadUserExcel")
    @ResponseBody
    public Map<String, Object> uploadUserExcel(@RequestParam("file") MultipartFile file) {
        int falseRow = userService.batchUploadUser(file);
        String msg = "insertFalse";
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", "0");
        map.put("msg", msg);
        map.put("data", falseRow);
        return map;
    }

    @RequestMapping("/uploadPoliceExcel")
    @ResponseBody
    public Map<String, Object> uploadPoliceExcel(@RequestParam("file") MultipartFile file) {
        int falseRow = policeService.batchUploadPolice(file);
        String msg = "insertFalse";
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", "0");
        map.put("msg", msg);
        map.put("data", falseRow);
        return map;
    }

    @RequestMapping("/deleteSelectedUser_info")
    @ResponseBody
    public int deleteSelectedUser_info(@RequestBody List<User> users) {
        return userService.deleteSelectedUser_info((ArrayList<User>) users);
    }

    @RequestMapping("/excelDownload")
    public void excelDownload(@RequestParam(value = "filename") String filename,
                              HttpServletRequest request,
                              HttpServletResponse response) throws IOException {
        //模拟文件，myfile.txt为需要下载的文件
        String path = request.getSession().getServletContext().getRealPath("static") + "/" + filename;
        //获取输入流
        InputStream bis = new BufferedInputStream(new FileInputStream(new File(path)));
        //转码，免得文件名中文乱码
        filename = URLEncoder.encode(filename, "UTF-8");
        //设置文件下载头
        response.addHeader("Content-Disposition", "attachment;filename=" + filename);
        //1.设置文件ContentType类型，这样设置，会自动判断下载文件类型
        response.setContentType("multipart/form-data");
        BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
        int len = 0;
        while ((len = bis.read()) != -1) {
            out.write(len);
            out.flush();
        }
        out.close();
    }

    @RequestMapping("/deleteUser_info")
    @ResponseBody
    public int deleteUser_info(@RequestParam("phoneNum") String phoneNum) {
        return userService.deleteUser(Long.parseLong(phoneNum));
    }

    @RequestMapping("/selectUser_Conditions")
    @ResponseBody
    public Map<String, Object> selectUser_Conditions(@RequestParam("page") int page,
                                                     @RequestParam("limit") int limit,
                                                     @RequestParam("phone_search") String phone_search,
                                                     @RequestParam("Name_search") String Name_search,
                                                     @RequestParam("gender") String gender,
                                                     @RequestParam("age") String age) {
        if (phone_search == "")
            phone_search = "1";
        if (Name_search == "")
            Name_search = null;
        if (gender.equals("0"))
            gender = null;
        if (age.equals("0"))
            age = null;
        List<User> userList = userService.selectByConditions(limit * (page - 1), limit, Long.parseLong(phone_search), Name_search, gender, age);
        Map<String, Object> selectUserMap = new HashMap<>();
        selectUserMap.put("code", 0);
        selectUserMap.put("msg", "ok");
        selectUserMap.put("count", userService.countUserByConditions(Long.parseLong(phone_search), Name_search, gender, age));
        selectUserMap.put("data", userList);
        return selectUserMap;
    }

    @RequestMapping("/updateUser_info")
    @ResponseBody
    public int updateUser_info(@RequestBody User user) {
        int i = userService.updateUserSelective(user);
        return i;
    }

    @RequestMapping("/selectAll_police_info")
    @ResponseBody
    public Map<String, Object> selectAll_police_info(@RequestParam("page") int page,
                                                     @RequestParam("limit") int limit) {
        List<Police> policeList = policeService.selectByPage(limit * (page - 1), limit);
        HashMap<String, Object> allPoliceMap = new HashMap<>();
        allPoliceMap.put("code", 0);
        allPoliceMap.put("msg", "ok");
        allPoliceMap.put("count", policeService.countAllPolice());
        allPoliceMap.put("data", policeList);
        return allPoliceMap;
    }

    @RequestMapping("/addPolice_info")
    @ResponseBody
    public int addPolice_info(@RequestBody Police police) {
        return policeService.addPolice(police);
    }

    @RequestMapping("/updatePolice_info")
    @ResponseBody
    public int updatePolice_info(@RequestBody Police police) {
        return policeService.updatePolice(police);
    }

    @RequestMapping("/deletePolice_info")
    @ResponseBody
    public int deletePolice_info(@RequestParam("policeId") int policeId) {
        return policeService.deletePolice(policeId);
    }

    @RequestMapping("/deleteSelectedPolice_info")
    @ResponseBody
    public int deleteSelectedPolice_info(@RequestBody List<Police> polices) {
        return policeService.deleteSelectedPolice_info((ArrayList<Police>) polices);
    }

    @RequestMapping("/selectPolice_Conditions")
    @ResponseBody
    public Map<String, Object> selectPolice_Conditions(@RequestParam("page") int page,
                                                       @RequestParam("limit") int limit,
                                                       @RequestParam("policeID_search") String policeID_search,
                                                       @RequestParam("organName_search") String organName_search) {
        if (policeID_search.equals(""))
            policeID_search = "1";
        if (organName_search.equals(""))
            organName_search = null;
        List<Police> policeList = policeService.selectByConditions(limit * (page - 1), limit,
                Integer.parseInt(policeID_search), organName_search);
        HashMap<String, Object> policeMap = new HashMap<>();
        policeMap.put("code", 0);
        policeMap.put("msg", "ok");
        policeMap.put("count", policeService.countPoliceByConditions(Integer.parseInt(policeID_search), organName_search));
        policeMap.put("data", policeList);
        return policeMap;
    }

    @RequestMapping("/selectAll_admin_info")
    @ResponseBody
    public Map<String, Object> selectAll_admin_info(@RequestParam("page") int page,
                                                    @RequestParam("limit") int limit) {
        List<Admin> admins = adminService.selectByPage(limit * (page - 1), limit);
        HashMap<String, Object> adminMap = new HashMap<>();
        adminMap.put("code", 0);
        adminMap.put("msg", "ok");
        adminMap.put("count", adminService.countAllAdmin());
        adminMap.put("data", admins);
        return adminMap;
    }

    @RequestMapping("/selectAdmin_Conditions")
    @ResponseBody
    public Map<String, Object> selectAdmin_Conditions(@RequestParam("page") int page,
                                                      @RequestParam("limit") int limit,
                                                      @RequestParam("adminID_search") String adminID_search,
                                                      @RequestParam("name_search") String name_search) {
        if (adminID_search.equals(""))
            adminID_search = "1";
        if (name_search.equals(""))
            name_search = null;
        List<Admin> admins = adminService.selectAdminByConditionds(limit * (page - 1), limit, Integer.parseInt(adminID_search), name_search);
        HashMap<String, Object> adminMap = new HashMap<>();
        adminMap.put("code", 0);
        adminMap.put("msg", "ok");
        adminMap.put("count", adminService.countAdminByConditions(Integer.parseInt(adminID_search), name_search));
        adminMap.put("data", admins);
        return adminMap;
    }

    @RequestMapping("/addAdmin")
    @ResponseBody
    public int addAdmin(@RequestBody Admin admin) {
        return adminService.addAdmin(admin);
    }

    @RequestMapping("/changeAdmin_info")
    @ResponseBody
    public int changeAdmin_info(@RequestBody Admin admin) {
        return adminService.changeAdminInfo(admin);
    }

    @RequestMapping("/selectAdmin_info")
    @ResponseBody
    public Admin selectAdmin_info(@RequestParam("adminID") String adminID) {
        return adminService.selectAdminInfo(Integer.parseInt(adminID));
    }

    @RequestMapping("/changePSW")
    @ResponseBody
    public int changePSW(@RequestBody Admin admin) {
        return adminService.changeAdminInfo(admin);
    }

    @RequestMapping("/adminOff")
    @ResponseBody
    public int adminOff(@RequestParam("adminID") String adminID) {
        return adminService.adminOff(Integer.parseInt(adminID));
    }
}
