package springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springmvc.dao.PoliceMapper;
import springmvc.dao.WaringInfoMapper;
import springmvc.entity.WaringInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class WaringInfoServiceImpl implements WaringInfoService {
    @Autowired
    WaringInfoMapper waringInfoMapper;
    @Autowired
    PoliceMapper policeMapper;

    @Override
    public int add_waring_info(WaringInfo waringInfo) {
        try {
            return waringInfoMapper.insertSelective(waringInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<WaringInfo> selectByPage(int start, int end) {
        try {
            return waringInfoMapper.selectByPage(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<WaringInfo> selectByConditions(int start, int end, String wTitle_search, String publish_organ_search, String grade_search, String pDate_search) {
        try {
            return waringInfoMapper.selectByConditions(start, end, wTitle_search, publish_organ_search, grade_search, pDate_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countAllWaring() {
        try {
            return waringInfoMapper.countAllWaring();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countWaringByConditions(String wTitle_search, String publish_organ_search, String grade_search, String pDate_search) {
        try {
            return waringInfoMapper.countWaringByConditions(wTitle_search, publish_organ_search, grade_search, pDate_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int deleteSelectedWaring_info(ArrayList<WaringInfo> waringInfos) {
        ArrayList<Long> waringIds = new ArrayList<>();
        for (WaringInfo waringInfo :
                waringInfos) {
            waringIds.add(waringInfo.getWaringId());
        }
        try {
            return waringInfoMapper.deleteSelectedWaringInfo(waringIds);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int deleteWaringInfo(Long waringId) {
        try {
            return waringInfoMapper.deleteByPrimaryKey(waringId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<WaringInfo> selectByProvince(int start, int end, String province) {
        List<String> policeIds = null;
        try {
            policeIds = policeMapper.selectPoliceIdByProvince(province);
        } catch (Exception e) {
            e.printStackTrace();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("start", start);
        map.put("end", end);
        map.put("collection", policeIds);
        try {
            return waringInfoMapper.selectByPoliceId(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<WaringInfo> selectByProvinceAndConditions(int start, int end, String province, String city, String time) {
        List<String> policeIds = null;
        try {
            policeIds = policeMapper.selectPoliceIdByProvinceAndCity(province, city);
        } catch (Exception e) {
            e.printStackTrace();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("start", start);
        map.put("end", end);
        map.put("time", time);
        map.put("collection", policeIds);
        try {
            return waringInfoMapper.selectByPoliceIdAndConditions(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countByPoliceId(String province) {
        List<String> policeIds = null;
        try {
            policeIds = policeMapper.selectPoliceIdByProvince(province);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            return waringInfoMapper.countByPoliceId(policeIds);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countByPoliceIdAndConditions(String province, String city, String time) {
        List<String> policeIds = null;
        try {
            policeIds = policeMapper.selectPoliceIdByProvinceAndCity(province, city);
        } catch (Exception e) {
            e.printStackTrace();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("collection", policeIds);
        map.put("time", time);
        try {
            return waringInfoMapper.countByPoliceIdAndConditions(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
