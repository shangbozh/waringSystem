package springmvc.service;

import org.springframework.stereotype.Service;
import springmvc.entity.User;
import springmvc.entity.WaringInfo;

import java.util.ArrayList;
import java.util.List;

@Service
public interface WaringInfoService {
    public int add_waring_info(WaringInfo waringInfo);

    public List<WaringInfo> selectByPage(int start, int end);

    public List<WaringInfo> selectByConditions(int start, int end, String wTitle_search, String publish_organ_search, String grade_search, String pDate_search);

    public int countAllWaring();

    public int countWaringByConditions(String wTitle_search, String publish_organ_search, String grade_search, String pDate_search);

    public int deleteSelectedWaring_info(ArrayList<WaringInfo> waringInfos);

    public int deleteWaringInfo(Long waringId);

    public List<WaringInfo> selectByProvince(int start, int end, String province);

    public List<WaringInfo> selectByProvinceAndConditions(int start, int end, String province, String city, String time);

    public int countByPoliceId(String province);

    public int countByPoliceIdAndConditions(String province, String city, String time);
}
