package springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import springmvc.dao.PoliceMapper;
import springmvc.entity.Police;
import springmvc.entity.PoliceBatchUpload;

import java.util.ArrayList;
import java.util.List;

@Service
public class PoliceServiceImpl implements PoliceService {
    @Autowired
    PoliceMapper policeMapper;

    @Override
    public Police police_login(String policeId, String password) {
        Police police = null;
        try {
            police = policeMapper.selectByPrimaryKey(Integer.parseInt(policeId));
            if (!police.getPassword().equals(password)) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
        return police;
    }

    @Override
    public int batchUploadPolice(MultipartFile file) {
        PoliceBatchUpload policeBatchUpload = new PoliceBatchUpload();
        List<Police> policeList = policeBatchUpload.getExcelInfo(file);
        for (int i = 0; i < policeList.size(); i++) {
            try {
                int i1 = policeMapper.insertSelective(policeList.get(i));
            } catch (Exception e) {
                e.printStackTrace();
                return i + 1;
            }
        }
        return 0;
    }

    @Override
    public List<Police> selectByPage(int start, int end) {
        try {
            return policeMapper.selectByPage(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Police> selectByConditions(int start, int end, int policeId, String organName_search) {
        try {
            return policeMapper.selectByConditions(start,end,policeId,organName_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countAllPolice() {
        try {
            return policeMapper.countAllPolice();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countPoliceByConditions(int policeId_search, String organName_search) {
        try {
            return policeMapper.countPoliceByConditions(policeId_search, organName_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    @Override
    public int deleteSelectedPolice_info(ArrayList<Police> polices) {
        ArrayList<Integer> policeIDs = new ArrayList<>();
        for (Police police :
                polices) {
            policeIDs.add(police.getPoliceId());
        }
        try {
            return policeMapper.deleteSelectedPolice(policeIDs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    @Override
    public int updatePoliceSelective(Police police) {
        try {
            return policeMapper.updateByPrimaryKeySelective(police);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int addPolice(Police police) {
        try {
            return policeMapper.insertSelective(police);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int updatePolice(Police police) {
        try {
            return policeMapper.updateByPrimaryKeySelective(police);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int deletePolice(int policeId) {
        try {
            return policeMapper.deleteByPrimaryKey(policeId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int changePSW(Police police) {
        try {
            return policeMapper.updateByPrimaryKeySelective(police);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public Police selectPoliceInfo(int policeId) {
        try {
            return policeMapper.selectByPrimaryKey(policeId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int policeOff(int policeId) {
        try {
            return policeMapper.deleteByPrimaryKey(policeId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
