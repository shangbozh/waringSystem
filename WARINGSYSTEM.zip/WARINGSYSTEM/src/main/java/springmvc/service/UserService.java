package springmvc.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import springmvc.entity.User;

import java.util.ArrayList;
import java.util.List;

@Service
public interface UserService {

    public User user_login(String username, String password);

    public int user_register(String username, String password);

    public User selectUserByPk(String phoneNum);

    public List<User> selectByPage(int start, int end);

    public List<User> selectByConditions(int start, int end, Long phone_search, String Name_search, String gender, String age);

    public int countAllUser();

    public int countUserByConditions(Long phone_search, String Name_search, String gender, String age);

    public int deleteSelectedUser_info(ArrayList<User> users);

    public int batchUploadUser(MultipartFile file);

    public int deleteUser(Long phoneNum);

    public int updateUserSelective(User user);

    public int userOff(Long phoneNum);

}
