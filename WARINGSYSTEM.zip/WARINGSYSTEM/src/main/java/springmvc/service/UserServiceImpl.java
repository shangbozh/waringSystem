package springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import springmvc.dao.UserMapper;
import springmvc.entity.User;
import springmvc.entity.UserBatchUpload;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public User user_login(String username, String password) {
        User user = null;
        try {
            user = userMapper.selectByPrimaryKey(Long.parseLong(username));
            if (!user.getPassword().equals(password)) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
        return user;

    }

    @Override
    public int user_register(String username, String password) {
        User user = new User();
        user.setPhoneNum(Long.parseLong(username));
        user.setPassword(password);
        try {
            return userMapper.insertSelective(user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public User selectUserByPk(String phoneNum) {

        try {
            return userMapper.selectByPrimaryKey(Long.parseLong(phoneNum));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<User> selectByPage(int start, int end) {
        try {
            return userMapper.selectByPage(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<User> selectByConditions(int start, int end, Long phone_search, String Name_search, String gender, String age) {
        try {
            return userMapper.selectByConditions(start, end, phone_search, Name_search, gender, age);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countAllUser() {
        try {
            return userMapper.countAllUser();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countUserByConditions(Long phone_search, String Name_search, String gender, String age) {
        try {
            return userMapper.countUserByConditions(phone_search, Name_search, gender, age);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;

    }


    @Override
    public int deleteSelectedUser_info(ArrayList<User> users) {
        ArrayList<Long> userPhoneNums = new ArrayList<>();
        for (User user :
                users) {
            userPhoneNums.add(user.getPhoneNum());
        }
        try {
            return userMapper.deleteSelectedUser(userPhoneNums);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override//批量添加用户，若有一行失败则返回行数，其后的数据全部插入失败
    public int batchUploadUser(MultipartFile file) {
        UserBatchUpload userBatchUpload = new UserBatchUpload();
        List<User> userList = userBatchUpload.getExcelInfo(file);
        for (User user :
                userList) {
        }
        for (int i = 0; i < userList.size(); i++) {
            try {
                int i1 = userMapper.insertSelective(userList.get(i));
            } catch (Exception e) {
                e.printStackTrace();
                return i + 1;
            }
        }
        return 0;
    }

    @Override
    public int deleteUser(Long phoneNum) {
        try {
            return userMapper.deleteByPrimaryKey(phoneNum);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int updateUserSelective(User user) {
        try {
            return userMapper.updateByPrimaryKeySelective(user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int userOff(Long phoneNum) {
        try {
            return userMapper.deleteByPrimaryKey(phoneNum);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

}
