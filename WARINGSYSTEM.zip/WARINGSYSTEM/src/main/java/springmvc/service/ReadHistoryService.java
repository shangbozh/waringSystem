package springmvc.service;

import org.springframework.stereotype.Service;
import springmvc.entity.ReadHistory;

import java.util.List;

@Service
public interface ReadHistoryService {

    public int insertReadHistory(ReadHistory readHistory);

    public List<ReadHistory> selectByPage(int start, int end);

    public int countAllReadHistory();

    public int countReadHistoryByConditions(String readTitle_search, String readDate_search);

    public List<ReadHistory> selectByPageByConditions(int start, int end,String readTitle_search, String readDate_search);

}
