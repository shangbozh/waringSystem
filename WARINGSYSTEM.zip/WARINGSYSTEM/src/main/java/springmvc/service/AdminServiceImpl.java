package springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springmvc.dao.AdminMapper;
import springmvc.entity.Admin;
import springmvc.entity.User;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;

    @Override
    public Admin admin_login(String username, String password) {
        Admin admin = null;
        try {
            admin = adminMapper.selectByPrimaryKey(Integer.parseInt(username));
            if (!admin.getPassword().equals(password)) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
        return admin;
    }

    @Override
    public List<Admin> selectByPage(int start, int end) {
        try {
            return adminMapper.selectByPage(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Admin> selectAdminByConditionds(int start, int end, int adminID_search, String name_search) {
        try {
            return adminMapper.selectByConditions(start, end, adminID_search, name_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countAllAdmin() {
        try {
            return adminMapper.countAllAdmin();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countAdminByConditions(int adminID_search, String name_search) {
        try {
            return adminMapper.countAdminByConditions(adminID_search, name_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int addAdmin(Admin admin) {
        try {
            return adminMapper.addAdmin(admin.getName(), admin.getPassword(), admin.getRole(), admin.getTel());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int changeAdminInfo(Admin admin) {
        try {
            return adminMapper.updateByPrimaryKeySelective(admin);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public Admin selectAdminInfo(int adminID) {
        try {
            return adminMapper.selectByPrimaryKey(adminID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int adminOff(int adminID) {
        try {
            return adminMapper.deleteByPrimaryKey(adminID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


}
