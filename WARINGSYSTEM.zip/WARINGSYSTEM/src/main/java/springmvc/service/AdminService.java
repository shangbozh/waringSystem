package springmvc.service;

import org.springframework.stereotype.Service;
import springmvc.entity.Admin;
import springmvc.entity.User;

import java.util.List;

@Service
public interface AdminService {
    public Admin admin_login(String username, String password);

    public List<Admin> selectByPage(int start, int end);

    public List<Admin> selectAdminByConditionds(int start, int end, int adminID_search, String name_search);

    public int countAllAdmin();

    public int countAdminByConditions(int adminID_search, String name_search);

    public int addAdmin(Admin admin);

    public int changeAdminInfo(Admin admin);

    public Admin selectAdminInfo(int adminID);

    public int adminOff(int adminID);
}
