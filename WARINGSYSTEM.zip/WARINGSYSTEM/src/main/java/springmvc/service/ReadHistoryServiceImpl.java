package springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springmvc.dao.ReadHistoryMapper;
import springmvc.dao.WaringInfoMapper;
import springmvc.entity.ReadHistory;

import java.util.HashMap;
import java.util.List;

@Service
public class ReadHistoryServiceImpl implements ReadHistoryService {
    @Autowired
    ReadHistoryMapper readHistoryMapper;
    @Autowired
    WaringInfoMapper waringInfoMapper;

    @Override
    public int insertReadHistory(ReadHistory readHistory) {
        try {
            return readHistoryMapper.insertSelective(readHistory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<ReadHistory> selectByPage(int start, int end) {
        try {
            return readHistoryMapper.selectByPage(start, end);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countAllReadHistory() {
        try {
            return readHistoryMapper.countAllReadHistory();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int countReadHistoryByConditions(String readTitle_search, String readDate_search) {
        List<String> waringId = null;
        try {
            waringId = waringInfoMapper.selectWaringIdByTitle(readTitle_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("readDate_search", readDate_search);
        map.put("waringIds", waringId);
        try {
            return readHistoryMapper.countReadHistoryByConditions(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<ReadHistory> selectByPageByConditions(int start, int end, String readTitle_search, String readDate_search) {
        List<String> waringId = null;
        try {
            waringId = waringInfoMapper.selectWaringIdByTitle(readTitle_search);
        } catch (Exception e) {
            e.printStackTrace();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("start", start);
        map.put("end", end);
        map.put("readDate_search", readDate_search);
        map.put("waringIds", waringId);
        try {
            return readHistoryMapper.selectReadHistoryByConditions(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
