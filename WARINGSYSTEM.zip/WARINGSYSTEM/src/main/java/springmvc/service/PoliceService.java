package springmvc.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import springmvc.entity.Police;
import springmvc.entity.User;

import java.util.ArrayList;
import java.util.List;

@Service
public interface PoliceService {
    public Police police_login(String policeId, String password);

    public int batchUploadPolice(MultipartFile file);

    public List<Police> selectByPage(int start, int end);

    public List<Police> selectByConditions(int start, int end, int policeId_search, String organName_search);

    public int countAllPolice();

    public int countPoliceByConditions(int policeId_search, String organName_search);

    public int deleteSelectedPolice_info(ArrayList<Police> polices);

    public int updatePoliceSelective(Police police);

    public int addPolice(Police police);

    public int updatePolice(Police police);

    public int deletePolice(int policeId);

    public int changePSW(Police police);

    public Police selectPoliceInfo(int policeId);

    public int policeOff(int policeId);
}
