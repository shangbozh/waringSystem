package springmvc.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import springmvc.entity.Admin;
import springmvc.entity.AdminExample;
import springmvc.entity.User;

public interface AdminMapper {
    int countByExample(AdminExample example);

    int deleteByExample(AdminExample example);

    int deleteByPrimaryKey(Integer adminId);

    int insert(Admin record);

    int insertSelective(Admin record);

    List<Admin> selectByExample(AdminExample example);

    Admin selectByPrimaryKey(Integer adminId);

    int updateByExampleSelective(@Param("record") Admin record, @Param("example") AdminExample example);

    int updateByExample(@Param("record") Admin record, @Param("example") AdminExample example);

    int updateByPrimaryKeySelective(Admin record);

    int updateByPrimaryKey(Admin record);

    //自定义方法
    List<Admin> selectByPage(@Param("start") int start, @Param("end") int end);

    List<Admin> selectByConditions(@Param("start") int start, @Param("end") int end,
                                   @Param("adminID_search") int adminID_search,
                                   @Param("name_search") String name_search);

    int countAllAdmin();

    int countAdminByConditions(@Param("adminID_search") int adminID_search,
                               @Param("name_search") String name_search);

    int addAdmin(@Param("add_name") String add_name,
                 @Param("add_password") String add_password,
                 @Param("add_role") String add_role,
                 @Param("add_tel") String add_tel);

}