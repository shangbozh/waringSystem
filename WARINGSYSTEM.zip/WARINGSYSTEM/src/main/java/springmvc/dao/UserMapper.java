package springmvc.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import springmvc.entity.User;
import springmvc.entity.UserExample;

public interface UserMapper {
    int countByExample(UserExample example);

    int deleteByExample(UserExample example);

    int deleteByPrimaryKey(Long phoneNum);

    int insert(User record);

    int insertSelective(User record);

    List<User> selectByExample(UserExample example);

    User selectByPrimaryKey(Long phoneNum);

    int updateByExampleSelective(@Param("record") User record, @Param("example") UserExample example);

    int updateByExample(@Param("record") User record, @Param("example") UserExample example);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

    //    自定义，以上的都是mybatis自动生成
    List<User> selectByPage(@Param("start") int start, @Param("end") int end);

    List<User> selectByConditions(@Param("start") int start, @Param("end") int end,
                                  @Param("phone_search") Long phone_search,
                                  @Param("Name_search") String Name_search,
                                  @Param("gender") String gender,
                                  @Param("age") String age);
    int countAllUser();

    int countUserByConditions(@Param("phone_search") Long phone_search,
                              @Param("Name_search") String Name_search,
                              @Param("gender") String gender,
                              @Param("age") String age);

    int deleteSelectedUser(List<Long> phoneNums);
}