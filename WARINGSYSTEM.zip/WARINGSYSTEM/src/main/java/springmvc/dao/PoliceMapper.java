package springmvc.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import springmvc.entity.Police;
import springmvc.entity.PoliceExample;

public interface PoliceMapper {
    int countByExample(PoliceExample example);

    int deleteByExample(PoliceExample example);

    int deleteByPrimaryKey(Integer policeId);

    int insert(Police record);

    int insertSelective(Police record);

    List<Police> selectByExample(PoliceExample example);

    Police selectByPrimaryKey(Integer policeId);

    int updateByExampleSelective(@Param("record") Police record, @Param("example") PoliceExample example);

    int updateByExample(@Param("record") Police record, @Param("example") PoliceExample example);

    int updateByPrimaryKeySelective(Police record);

    int updateByPrimaryKey(Police record);


    //以下为自定义，上面为mybatis自动生成
    List<Police> selectByPage(@Param("start") int start, @Param("end") int end);

    List<Police> selectByConditions(@Param("start") int start, @Param("end") int end,
                                    @Param("policeId_search") int policeId_search,
                                    @Param("organName_search") String organName_search);

    int countAllPolice();

    int countPoliceByConditions(@Param("policeId_search") int policeId_search,
                                @Param("organName_search") String organName_search);

    int deleteSelectedPolice(List<Integer> policeIds);

    List<String> selectPoliceIdByProvince(@Param("province") String province);

    List<String> selectPoliceIdByProvinceAndCity(@Param("province") String province,
                                                 @Param("city") String city);


}