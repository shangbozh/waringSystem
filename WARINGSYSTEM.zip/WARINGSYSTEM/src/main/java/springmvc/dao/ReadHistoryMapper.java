package springmvc.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import springmvc.entity.ReadHistory;
import springmvc.entity.ReadHistoryExample;
import springmvc.entity.ReadHistoryKey;
import springmvc.entity.User;

public interface ReadHistoryMapper {
    int countByExample(ReadHistoryExample example);

    int deleteByExample(ReadHistoryExample example);

    int deleteByPrimaryKey(ReadHistoryKey key);

    int insert(ReadHistory record);

    int insertSelective(ReadHistory record);

    List<ReadHistory> selectByExample(ReadHistoryExample example);

    ReadHistory selectByPrimaryKey(ReadHistoryKey key);

    int updateByExampleSelective(@Param("record") ReadHistory record, @Param("example") ReadHistoryExample example);

    int updateByExample(@Param("record") ReadHistory record, @Param("example") ReadHistoryExample example);

    int updateByPrimaryKeySelective(ReadHistory record);

    int updateByPrimaryKey(ReadHistory record);

    //    自定义，以上的都是mybatis自动生成
    List<ReadHistory> selectByPage(@Param("start") int start, @Param("end") int end);

    List<ReadHistory> selectByConditions(@Param("start") int start, @Param("end") int end,
                                         @Param("gender") String gender,
                                         @Param("age") String age);

    int countAllReadHistory();

    int countReadHistoryByConditions(HashMap map);

    List<ReadHistory> selectReadHistoryByConditions(HashMap map);
}