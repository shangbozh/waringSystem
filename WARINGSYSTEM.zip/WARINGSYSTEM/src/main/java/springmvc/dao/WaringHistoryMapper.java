package springmvc.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import springmvc.entity.WaringHistory;
import springmvc.entity.WaringHistoryExample;

public interface WaringHistoryMapper {
    int countByExample(WaringHistoryExample example);

    int deleteByExample(WaringHistoryExample example);

    int deleteByPrimaryKey(Long waringId);

    int insert(WaringHistory record);

    int insertSelective(WaringHistory record);

    List<WaringHistory> selectByExampleWithBLOBs(WaringHistoryExample example);

    List<WaringHistory> selectByExample(WaringHistoryExample example);

    WaringHistory selectByPrimaryKey(Long waringId);

    int updateByExampleSelective(@Param("record") WaringHistory record, @Param("example") WaringHistoryExample example);

    int updateByExampleWithBLOBs(@Param("record") WaringHistory record, @Param("example") WaringHistoryExample example);

    int updateByExample(@Param("record") WaringHistory record, @Param("example") WaringHistoryExample example);

    int updateByPrimaryKeySelective(WaringHistory record);

    int updateByPrimaryKeyWithBLOBs(WaringHistory record);

    int updateByPrimaryKey(WaringHistory record);
}