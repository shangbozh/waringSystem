package springmvc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import springmvc.entity.User;
import springmvc.entity.WaringInfo;
import springmvc.entity.WaringInfoExample;

public interface WaringInfoMapper {
    int countByExample(WaringInfoExample example);

    int deleteByExample(WaringInfoExample example);

    int deleteByPrimaryKey(Long waringId);

    int insert(WaringInfo record);

    int insertSelective(WaringInfo record);

    List<WaringInfo> selectByExampleWithBLOBs(WaringInfoExample example);

    List<WaringInfo> selectByExample(WaringInfoExample example);

    WaringInfo selectByPrimaryKey(Long waringId);

    int updateByExampleSelective(@Param("record") WaringInfo record, @Param("example") WaringInfoExample example);

    int updateByExampleWithBLOBs(@Param("record") WaringInfo record, @Param("example") WaringInfoExample example);

    int updateByExample(@Param("record") WaringInfo record, @Param("example") WaringInfoExample example);

    int updateByPrimaryKeySelective(WaringInfo record);

    int updateByPrimaryKeyWithBLOBs(WaringInfo record);

    int updateByPrimaryKey(WaringInfo record);

    //    自定义，以上的都是mybatis自动生成
    List<WaringInfo> selectByPage(@Param("start") int start, @Param("end") int end);

    List<WaringInfo> selectByConditions(@Param("start") int start, @Param("end") int end,
                                        @Param("wTitle_search") String wTitle_search,
                                        @Param("publish_organ_search") String publish_organ_search,
                                        @Param("grade_search") String grade_search,
                                        @Param("pDate_search") String pDate_search);

    int countAllWaring();

    int countWaringByConditions(@Param("wTitle_search") String wTitle_search,
                                @Param("publish_organ_search") String publish_organ_search,
                                @Param("grade_search") String grade_search,
                                @Param("pDate_search") String pDate_search);

    int deleteSelectedWaringInfo(List<Long> waringIds);

    List<WaringInfo> selectByPoliceId(HashMap map);

    List<WaringInfo> selectByPoliceIdAndConditions(HashMap map);

    int countByPoliceId(List<String> policeIds);

    int countByPoliceIdAndConditions(HashMap map);

    List<String> selectWaringIdByTitle(@Param("title") String title);
}