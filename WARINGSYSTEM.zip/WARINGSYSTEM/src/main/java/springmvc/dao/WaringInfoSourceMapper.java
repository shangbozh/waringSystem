package springmvc.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import springmvc.entity.WaringInfoSource;
import springmvc.entity.WaringInfoSourceExample;

public interface WaringInfoSourceMapper {
    int countByExample(WaringInfoSourceExample example);

    int deleteByExample(WaringInfoSourceExample example);

    int deleteByPrimaryKey(Long waringSourceId);

    int insert(WaringInfoSource record);

    int insertSelective(WaringInfoSource record);

    List<WaringInfoSource> selectByExampleWithBLOBs(WaringInfoSourceExample example);

    List<WaringInfoSource> selectByExample(WaringInfoSourceExample example);

    WaringInfoSource selectByPrimaryKey(Long waringSourceId);

    int updateByExampleSelective(@Param("record") WaringInfoSource record, @Param("example") WaringInfoSourceExample example);

    int updateByExampleWithBLOBs(@Param("record") WaringInfoSource record, @Param("example") WaringInfoSourceExample example);

    int updateByExample(@Param("record") WaringInfoSource record, @Param("example") WaringInfoSourceExample example);

    int updateByPrimaryKeySelective(WaringInfoSource record);

    int updateByPrimaryKeyWithBLOBs(WaringInfoSource record);

    int updateByPrimaryKey(WaringInfoSource record);
}